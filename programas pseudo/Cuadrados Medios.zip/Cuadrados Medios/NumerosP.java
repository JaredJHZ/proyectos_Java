/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Jared
 */
//Esta clase nos sirve para almacenar los valores ded x y de r
public class NumerosP {
    String x[];
    double r[];
    NumerosP(int tamaño){
        this.x = new String[tamaño];
        this.r = new double[tamaño];
    }
}
